<?php
/**
 * Plugin Name: AB Testing
 * Plugin URI: https://github.com/seu-usuario/ab-testing
 * Description: Plugin para testes A/B em páginas do WordPress.
 * Version: 1.0.0
 * Author: Seu Nome
 * Author URI: https://github.com/seu-usuario
 * License: GPL2
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 */

// Evita acesso direto ao arquivo
if (!defined('WPINC')) {
    die;
}

// Inclui os arquivos necessários
require_once plugin_dir_path(__FILE__) . 'includes/redirect.php';
require_once plugin_dir_path(__FILE__) . 'includes/stats.php';
require_once plugin_dir_path(__FILE__) . 'admin/settings.php';
require_once plugin_dir_path(__FILE__) . 'admin/dashboard.php';

// Ativa o plugin
function ab_testing_activate() {
    ab_testing_create_tests_table();
    ab_testing_create_stats_table();
}
register_activation_hook(__FILE__, 'ab_testing_activate');

// Adiciona o hook de redirecionamento
add_action('template_redirect', 'ab_testing_redirect');

// Adiciona o arquivo CSS
function ab_testing_enqueue_styles() {
    wp_enqueue_style('ab-testing-style', plugin_dir_url(__FILE__) . 'admin/css/style.css');
}
add_action('admin_enqueue_scripts', 'ab_testing_enqueue_styles');

// Inicia a sessão
function ab_testing_start_session() {
    if (!session_id()) {
        session_start();
    }
}
add_action('init', 'ab_testing_start_session', 1);

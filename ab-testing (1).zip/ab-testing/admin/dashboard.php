<?php
/**
 * Página do dashboard do plugin AB Testing.
 */

// Adiciona a página do dashboard ao menu do WordPress
function ab_testing_add_dashboard_menu() {
    add_submenu_page(
        'ab-testing',
        'Scalaê|AB Testing Dashboard',
        'Dashboard',
        'manage_options',
        'ab-testing-dashboard',
        'ab_testing_dashboard_page'
    );
}
add_action('admin_menu', 'ab_testing_add_dashboard_menu');

// Renderiza a página do dashboard
function ab_testing_dashboard_page() {
    // Verifica se o usuário tem permissão para acessar a página
    if (!current_user_can('manage_options')) {
        return;
    }

    // Obtém todos os testes
    $tests = ab_testing_get_all_tests();
    ?>
    <div class="wrap">
        <div class="plugin-header">
            <img src="<?php echo plugin_dir_url(__FILE__) . 'images/logo.png'; ?>" alt="Scalaê Logo" class="plugin-logo">
            <h1>Scalaê|AB Testing Dashboard</h1>
        </div>
        <div class="dashboard-container">
            <?php if (empty($tests)) : ?>
                <p>Nenhum teste salvo.</p>
            <?php else : ?>
                <?php foreach ($tests as $test) :
                    $stats = ab_testing_get_test_stats($test['id']);
                    error_log('Dashboard stats for test ' . $test['id'] . ': ' . print_r($stats, true));
                    $config = json_decode($test['config'], true);
                    ?>
                    <div class="dashboard-card">
                        <h3><?php echo esc_html($test['name']); ?></h3>
                        <p><strong>Página:</strong> <?php echo esc_html(get_the_title($test['page_id'])); ?></p>
                        <?php if (!empty($config)) : ?>
                            <h4>Estatísticas:</h4>
                            <?php foreach ($config as $variant => $data) :
                                $variant_stats = isset($stats[$variant]) ? $stats[$variant] : array('visits' => 0, 'conversions' => 0);
                                ?>
                                <p><strong>Variante:</strong> <?php echo esc_html($variant); ?></p>
                                <p><strong>Visitas:</strong> <?php echo esc_html($variant_stats['visits']); ?></p>
                                <p><strong>Conversões:</strong> <?php echo esc_html($variant_stats['conversions']); ?></p>
                            <?php endforeach; ?>
                        <?php else : ?>
                            <p>Nenhuma estatística disponível para este teste.</p>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
    <?php
}

<?php
/**
 * Página de configurações do plugin AB Testing.
 */

// Adiciona a página de configurações ao menu do WordPress
function ab_testing_add_admin_menu() {
    add_menu_page(
        'Scalaê|AB Testing', // Nome do plugin no menu
        'Scalaê|AB Testing', // Nome do plugin no menu
        'manage_options',
        'ab-testing',
        'ab_testing_settings_page',
        'dashicons-chart-line',
        80
    );
}
add_action('admin_menu', 'ab_testing_add_admin_menu');

// Renderiza a página de configurações
function ab_testing_settings_page() {
    // Verifica se o usuário tem permissão para acessar a página
    if (!current_user_can('manage_options')) {
        return;
    }

    // Salva as configurações se o formulário foi enviado
    if (isset($_POST['ab_testing_submit'])) {
        if (check_admin_referer('ab_testing_save_settings_action', 'ab_testing_save_settings_nonce')) {
            ab_testing_save_settings();
        } else {
            echo '<div class="error"><p>Erro de segurança ao salvar as configurações.</p></div>';
        }
    }

    // Exclui um teste se o formulário de exclusão foi enviado
    if (isset($_POST['ab_testing_delete_test']) && isset($_POST['ab_testing_delete_test_id'])) {
        if (check_admin_referer('ab_testing_delete_test_action', 'ab_testing_delete_test_nonce')) {
            ab_testing_delete_test(intval($_POST['ab_testing_delete_test_id']));
        } else {
            echo '<div class="error"><p>Erro de segurança ao excluir o teste.</p></div>';
        }
    }

    // Obtém os testes salvos
    $tests = ab_testing_get_all_tests();
    $selected_test_id = isset($_GET['test_id']) ? intval($_GET['test_id']) : 0;
    $selected_test = $selected_test_id ? ab_testing_get_test($selected_test_id) : null;
    $page_id = $selected_test ? $selected_test['page_id'] : '';
    $test_config = $selected_test ? json_decode($selected_test['config'], true) : array();
    $test_name = $selected_test ? $selected_test['name'] : '';

    ?>
    <div class="wrap">
        <div class="plugin-header">
            <img src="<?php echo plugin_dir_url(__FILE__) . 'images/logo.png'; ?>" alt="Scalaê Logo" class="plugin-logo">
            <h1>Scalaê|AB Testing</h1>
        </div>
        <form method="post" id="ab-testing-form">
            <label for="ab_testing_test_name">Nome do Teste:</label>
            <input type="text" name="ab_testing_test_name" id="ab_testing_test_name" value="<?php echo esc_attr($test_name); ?>" required><br><br>
            <label for="ab_testing_page_id">Página para Teste:</label>
            <select name="ab_testing_page_id" id="ab_testing_page_id">
                <option value="">Selecione uma página</option>
                <?php
                $pages = get_pages();
                foreach ($pages as $page) {
                    $selected = ($page_id == $page->ID) ? 'selected' : '';
                    echo '<option value="' . esc_attr($page->ID) . '" ' . $selected . '>' . esc_html($page->post_title) . '</option>';
                }
                ?>
            </select>
            <br><br>
            <div id="ab-testing-variants">
                <?php
                if (!empty($test_config)) {
                    foreach ($test_config as $variant => $config) {
                        ab_testing_render_variant_form($variant, $config);
                    }
                }
                ?>
            </div>
            <button type="button" id="add-variant">Adicionar Variante</button>
            <br><br>
            <input type="hidden" name="ab_testing_test_id" value="<?php echo esc_attr($selected_test_id); ?>">
            <?php wp_nonce_field('ab_testing_save_settings_action', 'ab_testing_save_settings_nonce'); ?>
            <input type="submit" name="ab_testing_submit" class="button button-primary" value="Salvar Configurações">
        </form>
        <br><br>
        <h2>Testes Salvos</h2>
        <table class="wp-list-table widefat fixed striped">
            <thead>
                <tr>
                    <th>Nome</th>
                    <th>Página</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($tests)) : ?>
                    <tr><td colspan="3">Nenhum teste salvo.</td></tr>
                <?php else : ?>
                    <?php foreach ($tests as $test) :
                        $edit_link = esc_url(add_query_arg('test_id', $test['id']));
                        error_log('Edit link for test ' . $test['id'] . ': ' . $edit_link);
                        ?>
                        <tr>
                            <td><?php echo esc_html($test['name']); ?></td>
                            <td><?php echo esc_html(get_the_title($test['page_id'])); ?></td>
                            <td>
                                <a href="<?php echo $edit_link; ?>">Editar</a>
                                <form method="post" style="display: inline;">
                                    <input type="hidden" name="ab_testing_delete_test" value="1">
                                    <input type="hidden" name="ab_testing_delete_test_id" value="<?php echo esc_attr($test['id']); ?>">
                                    <?php wp_nonce_field('ab_testing_delete_test_action', 'ab_testing_delete_test_nonce'); ?>
                                    <button type="submit" class="remove-variant" onclick="return confirm('Tem certeza que deseja excluir este teste?');">Excluir</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            let variantCount = <?php echo count(json_decode(wp_json_encode($test_config), true)); ?>;
            const addVariantButton = document.getElementById('add-variant');
            const variantsContainer = document.getElementById('ab-testing-variants');

            addVariantButton.addEventListener('click', function() {
                variantCount++;
                const newVariant = `
                    <div class="variant-form">
                        <h3>Variante ${variantCount}</h3>
                        <label>URL:</label>
                        <input type="text" name="ab_testing_config[variant_${variantCount}][url]" required><br>
                        <label>Porcentagem:</label>
                        <input type="number" name="ab_testing_config[variant_${variantCount}][percentage]" min="0" max="100" required><br>
                        <button type="button" class="remove-variant">Remover</button>
                    </div>
                `;
                variantsContainer.insertAdjacentHTML('beforeend', newVariant);
                attachRemoveButtonListeners();
            });

            function attachRemoveButtonListeners() {
                const removeButtons = document.querySelectorAll('.remove-variant');
                removeButtons.forEach(button => {
                    button.addEventListener('click', function() {
                        this.closest('.variant-form').remove();
                    });
                });
            }
            attachRemoveButtonListeners();
        });
    </script>
    <?php
}

// Renderiza o formulário de uma variante
function ab_testing_render_variant_form($variant, $config) {
    $variant_key = is_numeric($variant) ? 'variant_' . $variant : $variant;
    ?>
    <div class="variant-form">
        <h3>Variante <?php echo esc_html($variant); ?></h3>
         <label>URL:</label>
        <input type="text" name="ab_testing_config[<?php echo esc_attr($variant_key); ?>][url]" value="<?php echo esc_attr($config['url'] ?? ''); ?>" required><br>
        <label>Porcentagem:</label>
        <input type="number" name="ab_testing_config[<?php echo esc_attr($variant_key); ?>][percentage]" value="<?php echo esc_attr($config['percentage'] ?? ''); ?>" min="0" max="100" required><br>
        <button type="button" class="remove-variant">Remover</button>
    </div>
    <?php
}

// Salva as configurações do plugin
function ab_testing_save_settings() {
    $test_id = isset($_POST['ab_testing_test_id']) ? intval($_POST['ab_testing_test_id']) : 0;
    $test_name = sanitize_text_field($_POST['ab_testing_test_name']);
    $page_id = sanitize_text_field($_POST['ab_testing_page_id']);
    $config = array();

    if (isset($_POST['ab_testing_config'])) {
        foreach ($_POST['ab_testing_config'] as $key => $value) {
             $config[$key] = array(
                'url' => esc_url_raw($value['url'] ?? ''),
                'percentage' => intval($value['percentage'] ?? 0),
            );
        }
    }

    if ($test_id) {
        ab_testing_update_test($test_id, $test_name, $page_id, $config);
    } else {
        ab_testing_save_test($test_name, $page_id, $config);
    }
    
    // Redireciona para a página de configurações para exibir os testes salvos
    ?>
    <script>
        window.location.href = '<?php echo admin_url('admin.php?page=ab-testing'); ?>';
    </script>
    <?php
    exit;
}

// Exclui um teste
function ab_testing_delete_test($test_id) {
    global $wpdb;
    $table_name = $wpdb->prefix . 'ab_testing_tests';
    $wpdb->delete($table_name, array('id' => $test_id));
    
    // Redireciona para a página de configurações para exibir os testes salvos
    ?>
    <script>
        window.location.href = '<?php echo admin_url('admin.php?page=ab-testing'); ?>';
    </script>
    <?php
    exit;
}

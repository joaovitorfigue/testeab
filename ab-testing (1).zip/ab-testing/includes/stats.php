<?php
/**
 * Funções de estatísticas do plugin AB Testing.
 */

// Cria a tabela de testes
function ab_testing_create_tests_table() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'ab_testing_tests';
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE IF NOT EXISTS $table_name (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        name varchar(255) NOT NULL,
        page_id mediumint(9) NOT NULL,
        config longtext NOT NULL,
        PRIMARY KEY  (id)
    ) $charset_collate;";

    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    dbDelta($sql);
}

// Cria a tabela de estatísticas
function ab_testing_create_stats_table() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'ab_testing_stats';
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE IF NOT EXISTS $table_name (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        test_id mediumint(9) NOT NULL,
        variant varchar(255) NOT NULL,
        visits int(11) NOT NULL DEFAULT 0,
        conversions int(11) NOT NULL DEFAULT 0,
        PRIMARY KEY  (id)
    ) $charset_collate;";

    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    dbDelta($sql);
}

// Salva um novo teste
function ab_testing_save_test($name, $page_id, $config) {
    global $wpdb;
    $table_name = $wpdb->prefix . 'ab_testing_tests';
    $wpdb->insert(
        $table_name,
        array(
            'name' => $name,
            'page_id' => $page_id,
            'config' => json_encode($config)
        )
    );
}

// Atualiza um teste existente
function ab_testing_update_test($test_id, $name, $page_id, $config) {
    global $wpdb;
    $table_name = $wpdb->prefix . 'ab_testing_tests';
    $wpdb->update(
        $table_name,
        array(
            'name' => $name,
            'page_id' => $page_id,
            'config' => json_encode($config)
        ),
        array('id' => $test_id)
    );
}

// Obtém todos os testes
function ab_testing_get_all_tests() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'ab_testing_tests';
    $tests = $wpdb->get_results("SELECT * FROM $table_name", ARRAY_A);
    return $tests;
}

// Obtém um teste específico
function ab_testing_get_test($test_id) {
    global $wpdb;
    $table_name = $wpdb->prefix . 'ab_testing_tests';
    $test = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE id = %d", $test_id), ARRAY_A);
    return $test;
}

// Obtém as estatísticas de um teste
function ab_testing_get_test_stats($test_id) {
    global $wpdb;
    $table_name = $wpdb->prefix . 'ab_testing_stats';
    $stats = $wpdb->get_results($wpdb->prepare("SELECT variant, visits, conversions FROM $table_name WHERE test_id = %d", $test_id), ARRAY_A);
    error_log('ab_testing_get_test_stats called with test_id: ' . $test_id . ', results: ' . print_r($stats, true));
    $result = array();
    if ($stats) {
        foreach ($stats as $stat) {
            $result[$stat['variant']] = array(
                'visits' => $stat['visits'],
                'conversions' => $stat['conversions']
            );
        }
    }
    return $result;
}

// Salva uma visita
function ab_testing_save_visit($test_id, $variant) {
    global $wpdb;
    $table_name = $wpdb->prefix . 'ab_testing_stats';
    $existing_stat = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE test_id = %d AND variant = %s", $test_id, $variant), ARRAY_A);

    error_log('ab_testing_save_visit called with test_id: ' . $test_id . ', variant: ' . $variant);
    error_log('Session data: ' . print_r($_SESSION, true));

    if ($existing_stat) {
        $wpdb->update(
            $table_name,
            array('visits' => $existing_stat['visits'] + 1),
            array('test_id' => $test_id, 'variant' => $variant)
        );
        error_log('ab_testing_save_visit updated existing stat, new visits: ' . ($existing_stat['visits'] + 1));
    } else {
        $wpdb->insert(
            $table_name,
            array(
                'test_id' => $test_id,
                'variant' => $variant,
                'visits' => 1
            )
        );
        error_log('ab_testing_save_visit inserted new stat, visits: 1');
    }
}

// Salva uma conversão
function ab_testing_save_conversion($test_id, $variant) {
    global $wpdb;
    $table_name = $wpdb->prefix . 'ab_testing_stats';
    $existing_stat = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE test_id = %d AND variant = %s", $test_id, $variant), ARRAY_A);

    if ($existing_stat) {
        $wpdb->update(
            $table_name,
            array('conversions' => $existing_stat['conversions'] + 1),
            array('test_id' => $test_id, 'variant' => $variant)
        );
    } else {
        $wpdb->insert(
            $table_name,
            array(
                'test_id' => $test_id,
                'variant' => $variant,
                'conversions' => 1
            )
        );
    }
}

<?php
/**
 * Funções de redirecionamento do plugin AB Testing.
 */

include_once plugin_dir_path(__FILE__) . 'stats.php';

// Redireciona o usuário para a variante correta
function ab_testing_redirect() {
    if (is_admin()) {
        error_log('ab_testing_redirect: is_admin() is true, exiting.');
        return;
    }

    global $wpdb;
    $page_id = get_the_ID();
    error_log('ab_testing_redirect: Page ID: ' . $page_id);
    $table_name = $wpdb->prefix . 'ab_testing_tests';
    $test = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE page_id = %d", $page_id), ARRAY_A);

    if (!$test) {
        error_log('ab_testing_redirect: No test found for page ID: ' . $page_id);
        // Remove o cookie se não houver teste
        $cookie_name = 'ab_testing_variant_' . $page_id;
        if (isset($_COOKIE[$cookie_name])) {
            setcookie($cookie_name, '', time() - 3600, '/');
            error_log('ab_testing_redirect: Cookie removed for page ID: ' . $page_id);
        }
        return;
    }
    error_log('ab_testing_redirect: Test found: ' . print_r($test, true));

    $config = json_decode($test['config'], true);
    if (empty($config)) {
        error_log('ab_testing_redirect: Config is empty for test ID: ' . $test['id']);
        return;
    }
    error_log('ab_testing_redirect: Config: ' . print_r($config, true));

    $variant = ab_testing_get_variant($config);
    if (!$variant) {
        error_log('ab_testing_redirect: No variant found for test ID: ' . $test['id']);
        return;
    }
    error_log('ab_testing_redirect: Variant: ' . print_r($variant, true));

    $variant_key = key($variant);
    $variant_data = isset($variant[$variant_key]) ? $variant[$variant_key] : null;
    $variant_url = '';

    if ($variant_data && is_array($variant_data) && isset($variant_data['url'])) {
        $variant_url = $variant_data['url'];
    }
    error_log('ab_testing_redirect: Variant URL: ' . $variant_url);

    if (!empty($variant_url)) {
        $cookie_name = 'ab_testing_variant_' . $test['id'];
        if (!isset($_COOKIE[$cookie_name])) {
            error_log('ab_testing_redirect: Cookie not set, should redirect.');
            if (function_exists('ab_testing_save_visit')) {
                error_log('ab_testing_redirect: Calling ab_testing_save_visit with test_id: ' . $test['id'] . ', variant_key: ' . $variant_key);
                ab_testing_save_visit($test['id'], $variant_key);
            } else {
                error_log('ab_testing_redirect: ab_testing_save_visit function does not exist.');
            }
            
            // Obtém os parâmetros UTM da URL atual
            $utm_params = array();
            if (isset($_SERVER['QUERY_STRING'])) {
                parse_str($_SERVER['QUERY_STRING'], $query_params);
                foreach ($query_params as $key => $value) {
                    if (strpos($key, 'utm_') === 0) {
                       $utm_params[$key] = sanitize_text_field($value);
                    }
                }
            }

            // Adiciona os parâmetros UTM à URL da variante
            if (!empty($utm_params)) {
                $variant_url = ab_testing_build_url_with_params($variant_url, $utm_params);
            }

            setcookie($cookie_name, $variant_key, time() + (86400 * 30), '/'); // Cookie válido por 30 dias
            error_log('ab_testing_redirect: Redirecting to: ' . $variant_url);
            wp_redirect($variant_url, 302);
            exit;
        } else {
            $cookie_variant = $_COOKIE[$cookie_name];
            error_log('ab_testing_redirect: Cookie found, variant: ' . $cookie_variant);
            
            // Verifica se a variante do cookie ainda existe na configuração do teste
            if (isset($config[$cookie_variant])) {
                $variant_data = $config[$cookie_variant];
                $variant_url = '';

                if ($variant_data && is_array($variant_data) && isset($variant_data['url'])) {
                    $variant_url = $variant_data['url'];
                }
                
                // Obtém os parâmetros UTM da URL atual
                $utm_params = array();
                if (isset($_SERVER['QUERY_STRING'])) {
                    parse_str($_SERVER['QUERY_STRING'], $query_params);
                    foreach ($query_params as $key => $value) {
                        if (strpos($key, 'utm_') === 0) {
                           $utm_params[$key] = sanitize_text_field($value);
                        }
                    }
                }

                // Adiciona os parâmetros UTM à URL da variante
                if (!empty($utm_params)) {
                    $variant_url = ab_testing_build_url_with_params($variant_url, $utm_params);
                }

                error_log('ab_testing_redirect: Redirecting to cookie variant: ' . $variant_url);
                wp_redirect($variant_url, 302);
                exit;
            } else {
                // Se a variante do cookie não existir mais, remove o cookie e redireciona normalmente
                error_log('ab_testing_redirect: Cookie variant not found in config, removing cookie and redirecting normally.');
                setcookie($cookie_name, '', time() - 3600, '/');
                
                if (function_exists('ab_testing_save_visit')) {
                    error_log('ab_testing_redirect: Calling ab_testing_save_visit with test_id: ' . $test['id'] . ', variant_key: ' . $variant_key);
                    ab_testing_save_visit($test['id'], $variant_key);
                } else {
                    error_log('ab_testing_redirect: ab_testing_save_visit function does not exist.');
                }
                
                // Obtém os parâmetros UTM da URL atual
                $utm_params = array();
                if (isset($_SERVER['QUERY_STRING'])) {
                    parse_str($_SERVER['QUERY_STRING'], $query_params);
                    foreach ($query_params as $key => $value) {
                        if (strpos($key, 'utm_') === 0) {
                           $utm_params[$key] = sanitize_text_field($value);
                        }
                    }
                }

                // Adiciona os parâmetros UTM à URL da variante
                if (!empty($utm_params)) {
                    $variant_url = ab_testing_build_url_with_params($variant_url, $utm_params);
                }

                error_log('ab_testing_redirect: Redirecting to: ' . $variant_url);
                wp_redirect($variant_url, 302);
                exit;
            }
        }
    }
}

// Função auxiliar para construir a URL com parâmetros
function ab_testing_build_url_with_params($url, $params) {
    $url_parts = parse_url($url);
    $query = isset($url_parts['query']) ? $url_parts['query'] : '';
    parse_str($query, $query_params);
    $new_query_params = array_merge($query_params, $params);
    $new_url = (isset($url_parts['scheme']) ? $url_parts['scheme'] . '://' : '') . (isset($url_parts['host']) ? $url_parts['host'] : '') . (isset($url_parts['path']) ? $url_parts['path'] : '') . '?' . http_build_query($new_query_params);
    return $new_url;
}

// Obtém a variante para o usuário
function ab_testing_get_variant($config) {
    $total_percentage = 0;
    foreach ($config as $variant => $data) {
        $total_percentage += $data['percentage'];
    }

    if ($total_percentage != 100) {
        error_log('ab_testing_get_variant: Total percentage is not 100.');
        return false;
    }

    $random_number = mt_rand(1, 100);
    $cumulative_percentage = 0;

    foreach ($config as $variant => $data) {
        $cumulative_percentage += $data['percentage'];
        if ($random_number <= $cumulative_percentage) {
            error_log('ab_testing_get_variant: Variant selected: ' . $variant);
            return array($variant => $data);
        }
    }
    error_log('ab_testing_get_variant: No variant selected.');
    return false;
}
